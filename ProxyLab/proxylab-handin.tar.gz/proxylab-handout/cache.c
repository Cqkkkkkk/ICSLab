/*
 *	在缓存层面，使用了类似内存分配器的分级缓存策略，创建了5类缓存块，每个大小分别为1200B, 5200B,
 *	10240B, 25600B, 102400B，各类块的个数分别为20,20,10,10,5。每次在读缓存时搜索所有缓存块
 *	进行字符串比较，写缓存时在对应大小的块写。在多线程方面，采用了读者-写者模型对部分变量加锁。
 */
#include "csapp.h"
#include "cache.h"
#include <sys/time.h>
int cache_block_size[CACHENUM];
int cache_cnt[CACHENUM];
int verbose_ = 0;
cache_block** caches;
sem_t w;

int readcnt;
/*
 *	初始化缓存，以及每个缓存块对应的信号量。
 */
void init_cache() {
	if (verbose_)
		printf("Now init cache\n");
	cache_block_size[0] = 1200;
	cache_block_size[1] = 5200;
	cache_block_size[2] = 10240;
	cache_block_size[3] = 25600;
	cache_block_size[4] = 102400;
	cache_cnt[0] = 20;
	cache_cnt[1] = 20;
	cache_cnt[2] = 10;
	cache_cnt[3] = 10;
	cache_cnt[4] = 5;

	sem_init(&w, 0, 1);
	caches =
		(struct cache_block**)Malloc(sizeof(struct cache_block**) * CACHENUM);
	int i;
	for (i = 0; i < CACHENUM; i++) {
		caches[i]
			= (cache_block*)Malloc(cache_cnt[i] * sizeof(cache_block));
	}
	for (i = 0; i < CACHENUM; i++) {
		cache_block* cur = caches[i];
		int k;
		for (k = 0; k < cache_cnt[i]; k++) {
			cur[k].url = Malloc(sizeof(char) * MAXLINE);
			strcpy(cur[k].url, "");
			cur[k].data = Calloc(cache_block_size[i], sizeof(char));
			cur[k].size = 0;
			cur[k].time = 0;
			/* init the lock as free */
			sem_init(&cur[k].mutex, 0, 1);
		}
	}
	if (verbose_)
		printf("Cache init finished\n");

}
/*
 *	清除缓存，关闭每个块对应的信号量。
 */
void free_cache() {
	if (verbose_)
		printf("Now free cache\n");

	int i = 0;
	for (; i < CACHENUM; i++) {
		cache_block* cur = caches[i];
		int k;
		for (k = 0; k < cache_cnt[i]; k++) {
			free(cur[i].url);
			free(cur[i].data);
			/* destroy lock */
			sem_close(&cur[i].mutex);
		}
		free(caches[i]);
	}
	/* destroy lock */
	sem_close(&w);
	if (verbose_)
		printf("Cache freed\n");

}
/*
 *	遍历所有缓存块，找到对应的url是否被缓存。
 */
cache_block* find_cache(char* url) {
	if (verbose_)
		printf("Now find cache\n");

	cache_block* ans = NULL;
	printf("Read cache %s \n", url);
	int find_flag = 0;
	int tar = 0;
	while (tar < CACHENUM) {
		cache_block* p = caches[tar];
		int i;
		for (i = 0; i < cache_cnt[tar]; i++) {
			if (p[i].time != 0 && strcmp(url, p[i].url) == 0) {
				ans = p;
				find_flag = 1;
				break;
			}
		}
		if (find_flag == 1) break;
		tar++;
	}
	if (verbose_) {
		if (ans == NULL)
			printf("Cache not found\n");
		else
			printf("Cache found\n");
	}
	return ans;
}
/*
 *	判断一个块是否被缓存，如果被缓存则向客户发送缓存的数据，返回1. 否则返回0
 *	读缓存模型，在第一次开始读的时候加锁，最后一个读完的解锁。
 */
int Read_Cache_Response(char* url, int fd) {
	if (verbose_)
		printf("Trying cache boost\n");
	struct cache_block* p;
	if ((p = find_cache(url)) == NULL) {
		if(verbose_)
			printf("Not cached\n");
		return 0;
	}
	else {
		P(&p->mutex);
		readcnt++;
		if (readcnt == 1)
			P(&w);
		V(&p->mutex);
		p->time = GetCurTime();
		Response_Cached(fd, p->data, p->size);
		P(&p->mutex);
		readcnt--;
		if (readcnt == 0)
			V(&w);
		V(&p->mutex);
		if (verbose_)
			printf("Cache boost successful\n");
		return 1;
	}
}
/*
 *	向内存中对应大小的块中写缓存，写之前加锁，写完之后解锁。
 */
void write_cache(char* url, char* data, int len) {
	if (verbose_)
		printf("Now writing cache\n");
	int tar = 0;
	while (tar < CACHENUM && len > cache_block_size[tar])
		tar++;
	printf("Write cache %s %d\n", url, tar);
	/* find empty block */
	cache_block* p = caches[tar], * empty_block = NULL;
	int i;
	for (i = 0; i < cache_cnt[tar]; i++) {
		if (p[i].time == 0) {
			empty_block = &p[i];
			break;
		}
	}
	if (empty_block == NULL) {
		long long min = GetCurTime();
		for (i = 0; i < cache_cnt[tar]; i++) {
			if (p[i].time < min) {
				min = p[i].time;
				empty_block = &p[i];
			}
		}
	}
	P(&w);
	empty_block->time = GetCurTime();
	empty_block->size = len;
	memcpy(empty_block->url, url, MAXLINE);
	memcpy(empty_block->data, data, len);
	V(&w);
	if(verbose_)
		printf("Write Cache Successful\n");
}
/*
 *	获得当前系统的纳秒级别的时间
 */
long long GetCurTime() {
	struct timespec time;
	clock_gettime(CLOCK_PROCESS_CPUTIME_ID, &time);
	long long nstime = ((long long)time.tv_sec * 1000000 + time.tv_nsec / 1000);
	return nstime;
}