/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned addval_428(unsigned x)
{
    return x + 3347138781U;
}

void setval_328(unsigned *p)
{
    *p = 3284633928U;
}

void setval_127(unsigned *p)
{
    *p = 2421705527U;
}

unsigned getval_465()
{
    return 3284633928U;
}

unsigned addval_260(unsigned x)
{
    return x + 3284633920U;
}

unsigned getval_111()
{
    return 3281031768U;
}

void setval_159(unsigned *p)
{
    *p = 398692472U;
}

unsigned getval_252()
{
    return 2425379000U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

void setval_455(unsigned *p)
{
    *p = 3531917993U;
}

unsigned getval_147()
{
    return 3286272328U;
}

void setval_473(unsigned *p)
{
    *p = 2425673353U;
}

void setval_427(unsigned *p)
{
    *p = 3281043881U;
}

unsigned getval_401()
{
    return 3525364377U;
}

unsigned addval_247(unsigned x)
{
    return x + 3599326384U;
}

void setval_462(unsigned *p)
{
    *p = 2464188744U;
}

unsigned addval_499(unsigned x)
{
    return x + 2430634248U;
}

unsigned getval_422()
{
    return 3372272265U;
}

void setval_326(unsigned *p)
{
    *p = 3281049225U;
}

unsigned addval_337(unsigned x)
{
    return x + 3375939976U;
}

unsigned addval_346(unsigned x)
{
    return x + 3223372201U;
}

unsigned getval_188()
{
    return 3281114761U;
}

unsigned getval_288()
{
    return 3397999327U;
}

unsigned getval_426()
{
    return 3523791529U;
}

void setval_472(unsigned *p)
{
    *p = 3767093479U;
}

unsigned addval_391(unsigned x)
{
    return x + 3221280393U;
}

void setval_327(unsigned *p)
{
    *p = 3353381192U;
}

unsigned getval_461()
{
    return 3375939977U;
}

void setval_230(unsigned *p)
{
    *p = 1170396809U;
}

unsigned getval_379()
{
    return 3674789505U;
}

void setval_255(unsigned *p)
{
    *p = 3281046169U;
}

unsigned getval_348()
{
    return 3284830657U;
}

unsigned addval_268(unsigned x)
{
    return x + 3767224453U;
}

unsigned addval_286(unsigned x)
{
    return x + 3281046185U;
}

unsigned getval_442()
{
    return 3675832713U;
}

unsigned getval_182()
{
    return 3252717896U;
}

unsigned addval_214(unsigned x)
{
    return x + 2428606854U;
}

unsigned getval_295()
{
    return 2059589257U;
}

unsigned addval_225(unsigned x)
{
    return x + 3378561417U;
}

unsigned getval_276()
{
    return 3767091296U;
}

unsigned getval_167()
{
    return 3531915657U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
